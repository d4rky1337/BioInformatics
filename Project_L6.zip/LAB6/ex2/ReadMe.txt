Author: Pelmus Antonio Bogdan
Group:1242A
Description:This Python program performs an in-silico restriction digest simulation.
It is designed to read a multi-sequence FASTA file (specifically, one containing 10 influenza genome segments)
and computationally "cut" each segment's DNA sequence using the EcoRI (GAATTC) recognition site.
After digesting all 10 segments, it analyzes the results to determine which segment was cut into the most fragments.
Finally, it uses the matplotlib library to generate two stylized plots that visually mimic a real DNA electrophoresis gel:
A combined gel showing all 10 segment digests in separate lanes next to a DNA ladder.
A grid of 10 individual gels, each showing a single segment's digest against the ladder for clearer comparison.