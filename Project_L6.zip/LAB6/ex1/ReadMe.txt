Author: Pelmus Antonio Bogdan
Group:1242A
Description: This Python program is a DNA gel electrophoresis simulator.
It uses matplotlib to create a stylized, visual plot that mimics a real DNA gel.
The script first defines a set of known "Ladder" fragments and computationally generates 10 random "Sample" fragments.
It then plots all these fragments, mapping their length (molecular weight) to a position on the gel.
The simulation accurately models a real gel by placing shorter fragments (which move faster) near the bottom
and longer fragments (which move slower) near the top.