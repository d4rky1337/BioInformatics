# -*- coding: utf-8 -*-
"""
Created on Thu Jan 15 15:16:31 2026

@author: Antonio
"""

import json
import numpy as np
import matplotlib.pyplot as plt
import random
import os

def synthesize_text_from_matrix(json_path, length=30):
    # 1. Load the Matrix and Mapping
    if not os.path.exists(json_path):
        print(f"Error: {json_path} not found. Please run the previous step first.")
        return

    with open(json_path, 'r') as f:
        data = json.load(f)
    
    word_map = data['mapping']          # Maps 'A' -> 'blue'
    matrix = data['transition_matrix']  # Maps 'A' -> {'B': 0.5, ...}
    
    # 2. Pick a random starting symbol
    current_symbol = random.choice(list(matrix.keys()))
    generated_symbols = [current_symbol]
    
    # 3. Generate the sequence
    for _ in range(length - 1):
        # If the current word leads to nowhere (dead end), stop or restart
        if current_symbol not in matrix:
            break
            
        transitions = matrix[current_symbol]
        candidates = list(transitions.keys())
        probabilities = list(transitions.values())
        
        # Weighted random choice based on transition probabilities
        next_symbol = np.random.choice(candidates, p=probabilities)
        
        generated_symbols.append(next_symbol)
        current_symbol = next_symbol
        
    # 4. Decode symbols back to words
    decoded_text = " ".join([word_map[s] for s in generated_symbols])
    
    return decoded_text, generated_symbols, word_map

# ==========================================
# Execution
# ==========================================

output_text, symbols, mapping = synthesize_text_from_matrix('text_transition_matrix.json', length=30)

print("--- Synthesized Text Segment ---")
print(output_text)

# Optional: Plot the composition of the new text
plt.figure(figsize=(10, 5))
unique_syms = sorted(list(set(symbols)))
counts = [symbols.count(s) for s in unique_syms]
labels = [f"{s} ({mapping[s]})" for s in unique_syms]

plt.bar(labels, counts, color='purple', alpha=0.6, edgecolor='black')
plt.title('Word Frequency in Synthesized Segment')
plt.xlabel('Word')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()