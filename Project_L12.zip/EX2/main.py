# -*- coding: utf-8 -*-
"""
Created on Thu Jan 15 14:38:04 2026

@author: Antonio
"""

import random
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set seed for reproducibility
random.seed(42)

# ==========================================
# PART 1: DNA SEQUENCE
# ==========================================

def analyze_dna():
    # 1. Generate random DNA sequence (approx 50 letters)
    dna_alphabet = ['A', 'C', 'G', 'T']
    dna_length = 50
    dna_sequence = "".join(random.choices(dna_alphabet, k=dna_length))

    # 2. Compute transition counts
    dna_transitions = {n1: {n2: 0 for n2 in dna_alphabet} for n1 in dna_alphabet}

    for i in range(len(dna_sequence) - 1):
        current_n = dna_sequence[i]
        next_n = dna_sequence[i+1]
        dna_transitions[current_n][next_n] += 1

    # 3. Convert to probabilities
    dna_prob_matrix = {}
    for start_node, targets in dna_transitions.items():
        total = sum(targets.values())
        dna_prob_matrix[start_node] = {}
        for end_node, count in targets.items():
            dna_prob_matrix[start_node][end_node] = count / total if total > 0 else 0.0

    # 4. Save to JSON
    with open('dna_transition_matrix.json', 'w') as f:
        json.dump(dna_prob_matrix, f, indent=4)

    # 5. Plotting
    plt.figure(figsize=(8, 6))
    df_dna = pd.DataFrame(dna_prob_matrix).T
    sns.heatmap(df_dna, annot=True, cmap='Blues', fmt=".2f")
    plt.title('DNA Transition Probabilities')
    plt.ylabel('From Base')
    plt.xlabel('To Base')
    plt.savefig('dna_heatmap.png')
    plt.close()
    
    return dna_sequence

# ==========================================
# PART 2: ENGLISH TEXT
# ==========================================

def analyze_text():
    # 1. Generate random English text (approx 300 letters)
    vocab = ["the", "quick", "brown", "fox", "jumps", "over", "lazy", "dog", 
             "hello", "world", "sun", "moon", "sky", "blue"]
    
    text_words = []
    current_len = 0
    while current_len < 300:
        w = random.choice(vocab)
        text_words.append(w)
        current_len += len(w) + 1 # +1 for space

    # 2. Map words to ASCII symbols
    unique_words = sorted(list(set(text_words)))
    # Mapping words to symbols A, B, C...
    word_to_symbol = {word: chr(65 + i) for i, word in enumerate(unique_words)}
    symbol_to_word = {v: k for k, v in word_to_symbol.items()}

    # Convert text sequence to symbol sequence
    symbol_sequence = [word_to_symbol[w] for w in text_words]
    symbols_alphabet = sorted(list(word_to_symbol.values()))

    # 3. Compute transition counts
    text_transitions = {s1: {s2: 0 for s2 in symbols_alphabet} for s1 in symbols_alphabet}

    for i in range(len(symbol_sequence) - 1):
        curr_s = symbol_sequence[i]
        next_s = symbol_sequence[i+1]
        text_transitions[curr_s][next_s] += 1

    # 4. Convert to probabilities
    text_prob_matrix = {}
    for start_node, targets in text_transitions.items():
        total = sum(targets.values())
        text_prob_matrix[start_node] = {}
        for end_node, count in targets.items():
            text_prob_matrix[start_node][end_node] = count / total if total > 0 else 0.0

    # 5. Save to JSON
    output_data = {
        "mapping": symbol_to_word,
        "transition_matrix": text_prob_matrix
    }
    with open('text_transition_matrix.json', 'w') as f:
        json.dump(output_data, f, indent=4)

    # 6. Plotting
    plt.figure(figsize=(10, 8))
    df_text = pd.DataFrame(text_prob_matrix).T
    labels = [f"{s} ({symbol_to_word[s]})" for s in df_text.index]

    sns.heatmap(df_text, annot=True, cmap='Greens', fmt=".2f",
                xticklabels=labels, yticklabels=labels)
    plt.title('Word Transition Probabilities (Symbolic Representation)')
    plt.ylabel('From Word')
    plt.xlabel('To Word')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig('text_heatmap.png')
    plt.close()

# Execute functions
dna_seq = analyze_dna()
analyze_text()