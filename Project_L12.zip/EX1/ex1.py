# -*- coding: utf-8 -*-
"""
Created on Thu Jan 15 14:46:02 2026

@author: Antonio
"""

import numpy as np
import matplotlib.pyplot as plt

def predict_system_evolution(matrix, initial_vector, steps=5):
    """
    Predicts the state vector for a given number of steps.
    v_{t+1} = Matrix . v_t
    """
    # Store history for plotting (including step 0)
    history = [initial_vector]
    current_vector = initial_vector
    
    print(f"Step 0 (Initial): {np.round(current_vector, 4)}")
    
    for i in range(1, steps + 1):
        # Matrix multiplication: v_next = Matrix * v_current
        next_vector = np.dot(matrix, current_vector)
        
        history.append(next_vector)
        current_vector = next_vector
        print(f"Step {i}: {np.round(current_vector, 4)}")
        
    return np.array(history)

# ==========================================
# Main Execution
# ==========================================

# 1. Define Matrix Size
matrix_size = 4
np.random.seed(101)  # Fixed seed for reproducible results

# 2. Generate Data
# Creating a random square matrix
A = np.random.rand(matrix_size, matrix_size)

# Normalize rows so the values don't explode to infinity (Optional, makes it a transition matrix)
A = A / A.sum(axis=1, keepdims=True)

# Create a random initial vector
v0 = np.random.rand(matrix_size)
v0 = v0 / v0.sum() # Normalize initial vector

print("--- System Inputs ---")
print("Matrix:\n", np.round(A, 2))
print("Initial Vector:\n", np.round(v0, 2))
print("\n--- Prediction Loop ---")

# 3. Run the Prediction
history_array = predict_system_evolution(A, v0, steps=5)

# 4. Plotting the results
plt.figure(figsize=(10, 6))

# Plot the evolution of each component in the vector
steps_range = range(len(history_array))
markers = ['o', 's', '^', 'D', 'x']

for i in range(matrix_size):
    plt.plot(steps_range, history_array[:, i], 
             marker=markers[i % len(markers)], 
             label=f'Vector Component {i+1}', 
             linewidth=2)

plt.title(f'System Prediction over 5 Discrete Steps')
plt.xlabel('Step')
plt.ylabel('Value')
plt.xticks(steps_range)
plt.grid(True, linestyle='--', alpha=0.7)
plt.legend()
plt.tight_layout()
plt.show()