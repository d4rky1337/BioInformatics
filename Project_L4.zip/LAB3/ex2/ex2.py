import sys
from collections import Counter
import matplotlib.pyplot as plt

# --- Genetic Code (Codon to Amino Acid) ---
GENETIC_CODE = {
    # U Column
    'UUU': 'Phe', 'UUC': 'Phe',
    'UUA': 'Leu', 'UUG': 'Leu',
    # C Column
    'UCU': 'Ser', 'UCC': 'Ser', 'UCA': 'Ser', 'UCG': 'Ser',
    # A Column
    'UAU': 'Tyr', 'UAC': 'Tyr',
    'UAA': 'Stop', 'UAG': 'Stop',
    # G Column
    'UGU': 'Cys', 'UGC': 'Cys',
    'UGA': 'Stop', 'UGG': 'Trp',
    
    # U Column
    'CUU': 'Leu', 'CUC': 'Leu', 'CUA': 'Leu', 'CUG': 'Leu',
    # C Column
    'CCU': 'Pro', 'CCC': 'Pro', 'CCA': 'Pro', 'CCG': 'Pro',
    # A Column
    'CAU': 'His', 'CAC': 'His',
    'CAA': 'Gln', 'CAG': 'Gln',
    # G Column
    'CGU': 'Arg', 'CGC': 'Arg', 'CGA': 'Arg', 'CGG': 'Arg',
    
    # U Column
    'AUU': 'Ile', 'AUC': 'Ile', 'AUA': 'Ile',
    'AUG': 'Met', # Start Codon
    # C Column
    'ACU': 'Thr', 'ACC': 'Thr', 'ACA': 'Thr', 'ACG': 'Thr',
    # A Column
    'AAU': 'Asn', 'AAC': 'Asn',
    'AAA': 'Lys', 'AAG': 'Lys',
    # G Column
    'AGU': 'Ser', 'AGC': 'Ser',
    'AGA': 'Arg', 'AGG': 'Arg',
    
    # U Column
    'GUU': 'Val', 'GUC': 'Val', 'GUA': 'Val', 'GUG': 'Val',
    # C Column
    'GCU': 'Ala', 'GCC': 'Ala', 'GCA': 'Ala', 'GCG': 'Ala',
    # A Column
    'GAU': 'Asp', 'GAC': 'Asp',
    'GAA': 'Glu', 'GAG': 'Glu',
    # G Column
    'GGU': 'Gly', 'GGC': 'Gly', 'GGA': 'Gly', 'GGG': 'Gly',
}

def parse_fasta(filename: str) -> str:
    """
    Parses a FASTA file and returns the complete genome sequence as a single string.
    """
    print(f"Reading {filename}...")
    sequence = []
    try:
        with open(filename, 'r') as f:
            for line in f:
                if line.startswith('>'):
                    continue
                sequence.append(line.strip())
        
        full_sequence = "".join(sequence)
        if not full_sequence:
            print(f"Warning: No sequence data found in {filename}.")
        return full_sequence
        
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
        print("Please download the FASTA files and place them in the same directory.")
        sys.exit(1)
    except Exception as e:
        print(f"An error occurred while reading {filename}: {e}")
        sys.exit(1)

def transcribe_dna_to_rna(dna_sequence: str) -> str:
    """Converts a DNA sequence to its corresponding RNA sequence."""
    return dna_sequence.upper().replace('T', 'U').replace('N', '')

def calculate_codon_frequencies(rna_sequence: str) -> Counter:
    """
    Calculates the frequency of each 3-base codon in an RNA sequence.
    """
    codon_list = []
    for i in range(0, len(rna_sequence) - 2, 3):
        codon = rna_sequence[i:i+3]
        if len(codon) == 3:
            codon_list.append(codon)
    
    return Counter(codon_list)

def calculate_amino_acid_frequencies(codon_counts: Counter) -> Counter:
    """
    Converts codon frequencies to amino acid frequencies using the genetic code.
    """
    amino_counts = Counter()
    for codon, count in codon_counts.items():
        amino_acid = GENETIC_CODE.get(codon, 'Unknown')
        if amino_acid != 'Unknown':
            amino_counts[amino_acid] += count
    return amino_counts

def plot_top_codons_single_genome(codon_counts: Counter, title: str, filename: str):
    """
    Creates and saves a bar chart of the top 10 most frequent codons for a single genome.
    """
    common_codons = codon_counts.most_common(10)
    codons, counts = zip(*common_codons)
    
    plt.figure(figsize=(12, 7))
    plt.bar(codons, counts, color='skyblue')
    plt.title(title, fontsize=16)
    plt.xlabel('Codon', fontsize=12)
    plt.ylabel('Frequency (Count)', fontsize=12)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(filename)
    print(f"Chart saved as {filename}")
    plt.close()

def plot_combined_top_codons(covid_counts: Counter, influenza_counts: Counter, filename: str):
    """
    Creates and saves a bar chart comparing the top 10 codons from both genomes,
    with distinct colors for each.
    """
    # Get the top 10 from each, and combine their unique codons
    top_covid_codons = {codon for codon, _ in covid_counts.most_common(10)}
    top_influenza_codons = {codon for codon, _ in influenza_counts.most_common(10)}
    
    # Get all unique codons that appeared in the top 10 of either list
    all_top_codons = sorted(list(top_covid_codons.union(top_influenza_codons)))
    
    # Prepare data for plotting
    covid_values = [covid_counts.get(codon, 0) for codon in all_top_codons]
    influenza_values = [influenza_counts.get(codon, 0) for codon in all_top_codons]

    x = np.arange(len(all_top_codons)) # the label locations
    width = 0.35  # the width of the bars

    plt.figure(figsize=(15, 8))
    
    # Plot COVID-19 bars
    plt.bar(x - width/2, covid_values, width, label='COVID-19', color='coral')
    # Plot Influenza bars
    plt.bar(x + width/2, influenza_values, width, label='Influenza', color='mediumseagreen')

    plt.title('Top Codon Frequencies: COVID-19 vs. Influenza', fontsize=16)
    plt.xlabel('Codon', fontsize=12)
    plt.ylabel('Frequency (Count)', fontsize=12)
    plt.xticks(x, all_top_codons, rotation=45, ha='right')
    plt.legend()
    plt.tight_layout()
    plt.savefig(filename)
    print(f"Chart saved as {filename}")
    plt.close()


def main():
    # --- Define filenames ---
    # !!! IMPORTANT !!!
    # You must replace these with the actual names of your local FASTA files.
    covid_file = 'covid.fasta'
    influenza_file = 'influenza.fasta'
    
    print("--- Starting Codon Frequency Analysis ---")

    # --- Process COVID-19 ---
    covid_dna = parse_fasta(covid_file)
    covid_rna = transcribe_dna_to_rna(covid_dna)
    covid_codon_counts = calculate_codon_frequencies(covid_rna)
    
    # --- Process Influenza ---
    influenza_dna = parse_fasta(influenza_file)
    influenza_rna = transcribe_dna_to_rna(influenza_dna)
    influenza_codon_counts = calculate_codon_frequencies(influenza_rna)

    # --- 1. Plot Top 10 for COVID-19 ---
    plot_top_codons_single_genome(
        covid_codon_counts, 
        'Top 10 Most Frequent Codons in COVID-19', 
        'covid_top_10.png'
    )

    # --- 2. Plot Top 10 for Influenza ---
    plot_top_codons_single_genome(
        influenza_codon_counts, 
        'Top 10 Most Frequent Codons in Influenza', 
        'influenza_top_10.png'
    )

    # --- 3. Compare the 2 results and show the most frequent codons above the 2 genomes ---
    # This now generates the combined plot with different colors
    plot_combined_top_codons(
        covid_codon_counts, 
        influenza_codon_counts, 
        'combined_top_codons_comparison.png'
    )


    # --- 4. Show Top 3 Amino Acids in Console ---
    covid_amino_counts = calculate_amino_acid_frequencies(covid_codon_counts)
    influenza_amino_counts = calculate_amino_acid_frequencies(influenza_codon_counts)

    print("\n--- Top 3 Most Frequent Amino Acids (COVID-19) ---")
    for amino, count in covid_amino_counts.most_common(3):
        print(f"{amino}: {count:,} occurrences")

    print("\n--- Top 3 Most Frequent Amino Acids (Influenza) ---")
    for amino, count in influenza_amino_counts.most_common(3):
        print(f"{amino}: {count:,} occurrences")
        
    print("\n--- Analysis Complete ---")


if __name__ == "__main__":
    import numpy as np # Import numpy here as it's used only for combined plotting
    main()

