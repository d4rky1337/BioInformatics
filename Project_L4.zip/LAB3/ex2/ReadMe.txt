Author: Pelmus Antonio Bogdan
Group:1242A

COVID-19 vs. Influenza Codon Frequency Analysis

This Python script performs a comparative analysis of codon and amino acid frequencies between the genomes of COVID-19 (SARS-CoV-2) and an Influenza virus.

Features

Parses genome data from local FASTA files.

Transcribes DNA sequences to RNA.

Calculates and plots the top 10 most frequent codons for each virus individually.

Generates a combined, color-coded bar chart comparing the top codons from both genomes.

Prints the top 3 most frequent amino acids for each virus to the console.

Requirements

Python 3

matplotlib library

How to Run

Install Requirements:
You must have matplotlib installed. If not, run:

pip install matplotlib


Add Genome Files:
Download the FASTA files for both genomes and place them in the same directory as the script. Rename them to:

covid_genome.fasta

influenza_genome.fasta
(If your filenames are different, you must update them inside the codon_comparison.py script.)

Execute the Script:
Run the script from your terminal:

python codon_comparison.py


Expected Output

When you run the script, it will:

In your console: Print the top 3 most frequent amino acids for each virus.

In the project folder: Save three .png image files:

covid_top_10.png

influenza_top_10.png

combined_top_codons_comparison.png