GENETIC_CODE = {
    # U Column
    'UUU': 'Phe', 'UUC': 'Phe',
    'UUA': 'Leu', 'UUG': 'Leu',
    # C Column
    'UCU': 'Ser', 'UCC': 'Ser', 'UCA': 'Ser', 'UCG': 'Ser',
    # A Column
    'UAU': 'Tyr', 'UAC': 'Tyr',
    'UAA': 'Stop', 'UAG': 'Stop',
    # G Column
    'UGU': 'Cys', 'UGC': 'Cys',
    'UGA': 'Stop', 'UGG': 'Trp',

    # U Column
    'CUU': 'Leu', 'CUC': 'Leu', 'CUA': 'Leu', 'CUG': 'Leu',
    # C Column
    'CCU': 'Pro', 'CCC': 'Pro', 'CCA': 'Pro', 'CCG': 'Pro',
    # A Column
    'CAU': 'His', 'CAC': 'His',
    'CAA': 'Gln', 'CAG': 'Gln',
    # G Column
    'CGU': 'Arg', 'CGC': 'Arg', 'CGA': 'Arg', 'CGG': 'Arg',

    # U Column
    'AUU': 'Ile', 'AUC': 'Ile', 'AUA': 'Ile',
    'AUG': 'Met',  # Start Codon
    # C Column
    'ACU': 'Thr', 'ACC': 'Thr', 'ACA': 'Thr', 'ACG': 'Thr',
    # A Column
    'AAU': 'Asn', 'AAC': 'Asn',
    'AAA': 'Lys', 'AAG': 'Lys',
    # G Column
    'AGU': 'Ser', 'AGC': 'Ser',
    'AGA': 'Arg', 'AGG': 'Arg',

    # U Column
    'GUU': 'Val', 'GUC': 'Val', 'GUA': 'Val', 'GUG': 'Val',
    # C Column
    'GCU': 'Ala', 'GCC': 'Ala', 'GCA': 'Ala', 'GCG': 'Ala',
    # A Column
    'GAU': 'Asp', 'GAC': 'Asp',
    'GAA': 'Glu', 'GAG': 'Glu',
    # G Column
    'GGU': 'Gly', 'GGC': 'Gly', 'GGA': 'Gly', 'GGG': 'Gly',
}

def transcribe_dna_to_rna(dna_sequence: str) -> str:
    """Converts a DNA sequence to its corresponding RNA sequence."""
    return dna_sequence.upper().replace('T', 'U')

def translate_gene(dna_sequence: str) -> str:
    
    rna_sequence = transcribe_dna_to_rna(dna_sequence)
    
    start_index = rna_sequence.find('AUG')
    
    if start_index == -1:
        return "No start codon (AUG) found in the sequence."
        
    protein_sequence = []
    
    for i in range(start_index, len(rna_sequence) - 2, 3):
        codon = rna_sequence[i : i + 3]
        
        if len(codon) < 3:
            break
            
        amino_acid = GENETIC_CODE.get(codon, 'X')
        
        if amino_acid == 'Stop':
            break
            
        protein_sequence.append(amino_acid)
        
    return "".join(protein_sequence)

if __name__ == "__main__":
    print("--- Gene to Protein Translator ---")
    
    example_dna = "ATGTTCGGTGGATAA"
    print(f"\nExample DNA Sequence: {example_dna}")
    
    example_rna = transcribe_dna_to_rna(example_dna)
    print(f"Corresponding RNA:    {example_rna}")
    
    protein_result = translate_gene(example_dna)
    print(f"Translated Protein:   {protein_result}")
    
    print("\n" + "="*30)
    
    while True:
        user_dna = input("\nEnter your DNA sequence (or 'q' to quit): ")
        
        if user_dna.lower() == 'q':
            break
            
        if not user_dna:
            continue
            
        user_rna = transcribe_dna_to_rna(user_dna)
        print(f"Corresponding RNA:  {user_rna}")
            
        user_protein = translate_gene(user_dna)
        print(f"Translated Protein: {user_protein}")
        
    print("\nGoodbye!")

