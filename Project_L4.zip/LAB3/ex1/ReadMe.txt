Gene to Protein Translator

This Python script translates a gene's coding region (DNA sequence) into its corresponding RNA sequence and then into an amino acid (protein) sequence.

It uses the standard genetic code to map RNA codons to amino acids, starting translation at the first 'AUG' (start codon) and stopping at the first stop codon.

How to Run

Make sure you have Python installed.

Run the script from your terminal:

python gene_translator.py


The script will first show an example and then prompt you to enter your own DNA sequences.

Author: Pelmus Antonio
Group: 1242A