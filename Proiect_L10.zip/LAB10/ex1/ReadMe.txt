Author: Pelmus Antonio Bogdan
Group: 1242A
Description: This program is a DNA sequence analyzer that uses a sliding window (default 30bp)
to compute two specific bioinformatics metrics:
C+G Content (%): The percentage of Cytosine and Guanine bases.
Kappa Index of Coincidence (IC): A statistical measure of the randomness of the sequence characters.
It processes a hardcoded DNA sequence, calculates the average values for these metrics, determines the "Center of Weight" (centroid)
for the resulting data curves, and visualizes the results in three distinct matplotlib charts.