import matplotlib.pyplot as plt
import numpy as np

def calculate_cg_content(window_seq):
    """
    Calculates the C+G percentage of a DNA sequence window.
    Target verification value: ~29.27 (Average)
    """
    length = len(window_seq)
    if length == 0:
        return 0.0
    
    c_count = window_seq.count('C')
    g_count = window_seq.count('G')
    
    cg_percent = ((c_count + g_count) / length) * 100
    return cg_percent

def calculate_kappa_ic(window_seq):
    """
    Calculates the Index of Coincidence (Kappa).
    Formula: IC = Sum(n*(n-1)) / (N*(N-1)) * 100
    Target verification value: ~27.53 (Average)
    """
    length = len(window_seq)
    if length <= 1:
        return 0.0
    
    # Count frequencies of A, C, G, T
    counts = {base: window_seq.count(base) for base in ['A', 'C', 'G', 'T']}
    
    # Calculate numerator: sum of n(n-1)
    numerator = sum(n * (n - 1) for n in counts.values())
    
    # Calculate denominator: N(N-1)
    denominator = length * (length - 1)
    
    # Return IC scaled to percentage (common in bioinformatics tools like PromKappa)
    return (numerator / denominator) * 100

def calculate_center_of_weight(y_values):
    """
    Calculates the Center of Weight (Centroid) X-coordinate for a given curve.
    Formula: Sum(x * y) / Sum(y)
    """
    total_moment = 0
    total_weight = 0
    
    for x, y in enumerate(y_values):
        total_moment += x * y
        total_weight += y
        
    if total_weight == 0:
        return 0
    
    return total_moment / total_weight

def analyze_sequence(sequence, window_size=30):
    """
    Performs sliding window analysis on the sequence.
    """
    cg_values = []
    ic_values = []
    
    # Sliding window loop
    # We iterate from 0 to len(sequence) - window_size
    for i in range(len(sequence) - window_size + 1):
        window = sequence[i : i + window_size]
        
        cg = calculate_cg_content(window)
        ic = calculate_kappa_ic(window)
        
        cg_values.append(cg)
        ic_values.append(ic)
        
    return cg_values, ic_values

def main():
    # 1. Define the Sequence (S)
    # Note: The specific test sequence provided in the prompt.
    S = "CGGACTGATCTATCTAAAAAAAAAAAAAAAAAAAAAAAAAAACGTAGCATCTATCGATCTATCTAGCGATCTATCTACTACG"
    
    WINDOW_SIZE = 30
    
    print(f"Analyzing Sequence Length: {len(S)}")
    print(f"Window Size: {WINDOW_SIZE}")
    print("-" * 40)

    # 2. Generate Patterns (Step 3 & 4 logic inside loop)
    cg_pattern, ic_pattern = analyze_sequence(S, WINDOW_SIZE)
    
    # Calculate Averages to verify against the prompt's targets
    avg_cg = np.mean(cg_pattern)
    avg_ic = np.mean(ic_pattern)

    print(f"Calculated Average CG%: {avg_cg:.2f} (Target: 29.27)")
    print(f"Calculated Average IC:  {avg_ic:.2f} (Target: 27.53)")
    
    # 6. Calculate Center of Weight
    cg_cw = calculate_center_of_weight(cg_pattern)
    ic_cw = calculate_center_of_weight(ic_pattern)
    
    print("-" * 40)
    print(f"Center of Weight (CG Pattern): Index {cg_cw:.2f}")
    print(f"Center of Weight (IC Pattern): Index {ic_cw:.2f}")

    # 5. Plot the pattern on a chart
    # Increased figure size to accommodate 3 separate subplots
    plt.figure(figsize=(12, 12))

    # Subplot 1: C+G % Pattern
    plt.subplot(3, 1, 1)
    plt.plot(cg_pattern, label='C+G %', color='blue', linewidth=2)
    plt.title(f'C+G% Pattern (Window={WINDOW_SIZE}bp)')
    plt.xlabel('Window Start Position')
    plt.ylabel('Percentage')
    plt.legend()
    plt.grid(True, alpha=0.3)

    # Subplot 2: Kappa IC Pattern
    plt.subplot(3, 1, 2)
    plt.plot(ic_pattern, label='Kappa IC', color='red', linestyle='--', linewidth=2)
    plt.title(f'Kappa Index of Coincidence (Window={WINDOW_SIZE}bp)')
    plt.xlabel('Window Start Position')
    plt.ylabel('Index Value')
    plt.legend()
    plt.grid(True, alpha=0.3)

    # 7. Take the center of each pattern and plot it on a second chart
    # Subplot 3: Center of Weight Comparison
    plt.subplot(3, 1, 3)
    
    # Plotting dummy lines just to create the legend and scale
    plt.plot(cg_pattern, color='blue', alpha=0.1, label='Raw CG Trace') 
    plt.plot(ic_pattern, color='red', alpha=0.1, label='Raw IC Trace')
    
    # Plotting the Center of Weight points
    plt.scatter([cg_cw], [np.mean(cg_pattern)], color='blue', s=200, zorder=5, label='CG Center of Weight')
    plt.scatter([ic_cw], [np.mean(ic_pattern)], color='red', s=200, marker='X', zorder=5, label='IC Center of Weight')
    
    # Draw vertical lines to mark the center
    plt.axvline(x=cg_cw, color='blue', linestyle=':', alpha=0.6)
    plt.axvline(x=ic_cw, color='red', linestyle=':', alpha=0.6)

    plt.title('Center of Weight for DNA Patterns')
    plt.xlabel('Window Position')
    plt.ylabel('Average Value')
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()