# -*- coding: utf-8 -*-
"""
Created on Thu Dec  4 15:19:03 2025

@author: Antonio
"""
import numpy as np
import matplotlib.pyplot as plt
from Bio import SeqIO
from Bio.SeqUtils import molecular_weight
import math

def calculate_ods_metrics(sequence, window_size=200, step_size=50):
    """Calculates GC content and Shannon Entropy for sliding windows."""
    seq = str(sequence).upper()
    gcs = []
    entropies = []
    
    for i in range(0, len(seq) - window_size + 1, step_size):
        sub = seq[i : i+window_size]
        if len(sub) < window_size: break
        
        # Calculate Frequencies
        counts = {b: sub.count(b) for b in 'ACGT'}
        total = sum(counts.values())
        if total == 0: continue
        
        # GC Content (X-axis)
        gc = (counts['G'] + counts['C']) / total
        gcs.append(gc)
        
        # Shannon Entropy (Y-axis)
        entropy = 0
        for count in counts.values():
            p = count / total
            if p > 0:
                entropy -= p * math.log2(p)
        entropies.append(entropy)
        
    return gcs, entropies

def process_genomes(file_path, virus_type, color):
    data_points = []
    try:
        for record in SeqIO.parse(file_path, "fasta"):
            # 1. Calculate ODS clouds (GC and Entropy)
            gcs, ents = calculate_ods_metrics(record.seq)
            
            # 2. Calculate Center of Weight
            cx = np.mean(gcs) if gcs else 0
            cy = np.mean(ents) if ents else 0
            
            # 3. Calculate Molecular Weight
            # FIX: We use .transcribe() to turn the DNA-coded FASTA (T) into RNA (U)
            # so the weight calculator doesn't crash.
            try:
                # Attempt to transcribe (T -> U)
                rna_seq = record.seq.transcribe()
                mw_da = molecular_weight(rna_seq, seq_type="RNA")
            except:
                # Fallback: Treat as DNA if transcription fails or complex chars exist
                mw_da = molecular_weight(record.seq, seq_type="DNA")
            
            data_points.append({
                "name": record.id,
                "type": virus_type,
                "color": color,
                "gcs": gcs,
                "ents": ents,
                "cx": cx,
                "cy": cy,
                "mw_kda": mw_da / 1000.0 
            })
            
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
    return data_points

# --- Main Analysis ---
# Load your files here
flu_data = process_genomes("influenza.fasta", "Influenza", "blue")
cov_data = process_genomes("covid_variant.fasta", "COVID-19", "red")
all_data = flu_data + cov_data

# Plot 1: Objective Digital Stains (The Cloud)
plt.figure(figsize=(12, 6))
for d in all_data:
    plt.scatter(d['gcs'], d['ents'], c=d['color'], s=2, alpha=0.1)
plt.title("Objective Digital Stains (ODS)")
plt.xlabel("GC Content")
plt.ylabel("Shannon Entropy")
plt.grid(True, linestyle='--', alpha=0.5)
plt.savefig("ods_cloud.png")
plt.show()

# Plot 2: Centers of Weight
plt.figure(figsize=(10, 8))
for d in all_data:
    plt.scatter(d['cx'], d['cy'], c=d['color'], s=150, edgecolors='black')
    label = f"{d['name']}\n{d['mw_kda']:.1f} kDa"
    plt.text(d['cx'], d['cy'], label, fontsize=9, ha='left', va='bottom')

plt.title("Centers of Weight for ODS")
plt.xlabel("Mean GC Content")
plt.ylabel("Mean Entropy")
plt.grid(True)
plt.savefig("centers_weight.png")
plt.show()
