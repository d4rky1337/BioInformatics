Project Authors: Pelmus Antonio Bogdan, Buga Mihai
Involvement in the project: Code, Logic - Pelmus Antonio
Graphical User Interface, Code Debugging - Buga Mihai
Group: 1232A
Prerequisitories: tkinter library (filedialog, scrolledtext, messagebox, ttk), Python 3.x
Project utility: This program allows the user to upload a fasta file and analyze the sequences
using a sliding windows consisted of 30 positions.