import tkinter as tk
from tkinter import filedialog, scrolledtext, messagebox, ttk
from collections import Counter
import matplotlib.pyplot as plt

def fasta_reader(filepath):
    header = None
    seq_lines = []
    with open(filepath, "r") as file:
        for line in file:
            if line.startswith(">"):
                if header and seq_lines:
                    yield header, "".join(seq_lines)
                    seq_lines = []
                header = line.strip()
            else:
                seq_lines.append(line.strip())
        if header and seq_lines:
            yield header, "".join(seq_lines)

def process_sequences():
    file_path = filedialog.askopenfilename(
        title="Select FASTA/FNA File",
        filetypes=[("FASTA/FNA files", "*.fasta *.fa *.fna"), ("All files", "*.*")]
    )
    if not file_path:
        return

    result_text.delete(1.0, tk.END)
    progress_bar.start(10)
    root.update_idletasks()

    window_size = 30

    try:
        for idx, (header, sequence) in enumerate(fasta_reader(file_path), 1):
            result_text.insert(tk.END, f"Sequence {idx}:\n")
            result_text.insert(tk.END, f"Header Information:\n{header}\n\n")

            if len(sequence) < window_size:
                result_text.insert(tk.END, "Sequence too short for sliding window.\n\n")
                continue

            result_text.insert(tk.END, f"Sliding window size: {window_size}\n\n")

            a_vals, t_vals, g_vals, c_vals = [], [], [], []
            positions = []

            for i in range(len(sequence) - window_size + 1):
                window = sequence[i:i+window_size]
                counts = Counter(window)
                a = counts.get("A", 0) / window_size * 100
                t = counts.get("T", 0) / window_size * 100
                g = counts.get("G", 0) / window_size * 100
                c = counts.get("C", 0) / window_size * 100
                a_vals.append(a)
                t_vals.append(t)
                g_vals.append(g)
                c_vals.append(c)
                positions.append(i + 1)

                result_text.insert(tk.END, f"Window {i+1}-{i+window_size}:\n")
                result_text.insert(tk.END, f"  A: {a:.2f}%\n  T: {t:.2f}%\n  G: {g:.2f}%\n  C: {c:.2f}%\n\n")

            # Plot the relative frequencies
            plt.figure(figsize=(8, 4))
            plt.plot(positions, a_vals, label="A", linewidth=1.5)
            plt.plot(positions, t_vals, label="T", linewidth=1.5)
            plt.plot(positions, g_vals, label="G", linewidth=1.5)
            plt.plot(positions, c_vals, label="C", linewidth=1.5)
            plt.xlabel("Window Start Position")
            plt.ylabel("Relative Frequency (%)")
            plt.title(f"Nucleotide Composition (Sliding Window = {window_size})")
            plt.legend()
            plt.tight_layout()
            plt.show()

            result_text.insert(tk.END, "-"*60 + "\n\n")
            result_text.see(tk.END)
            root.update_idletasks()

    except Exception as e:
        messagebox.showerror("Error", f"Processing failed: {e}")
    finally:
        progress_bar.stop()

root = tk.Tk()
root.title("FASTA/FNA Analyzer with Sliding Window and Chart")
root.geometry("700x550")

choose_button = tk.Button(root, text="Choose FASTA/FNA File", command=process_sequences)
choose_button.pack(pady=10)

progress_bar = ttk.Progressbar(root, orient="horizontal", mode="indeterminate", length=400)
progress_bar.pack(pady=5)

result_text = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=80, height=25)
result_text.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

root.mainloop()
