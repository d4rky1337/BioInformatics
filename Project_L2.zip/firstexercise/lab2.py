import tkinter as tk
from tkinter import scrolledtext

SEQUENCE = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"
ALPHABET = ['A', 'T', 'C', 'G']

def make_di_kmers():
    di = []
    for x in ALPHABET:
        for y in ALPHABET:
            di.append(x + y)
    return di

def make_tri_kmers():
    tri = []
    for x in ALPHABET:
        for y in ALPHABET:
            for z in ALPHABET:
                tri.append(x + y + z)
    return tri

def count_kmer_stuff(s, k_list, k_len):
    total_possible_windows = len(s) - k_len + 1
    
    if total_possible_windows <= 0:
        return {}

    results = {}
    
    for kmer in k_list:
        c = s.count(kmer)
        p = (c / total_possible_windows) * 100
        results[kmer] = p
        
    return results

def button_click():
    s = seq_entry.get().upper().strip()
    
    text_out.delete(1.0, tk.END)
    text_out.insert(tk.END, "Working on sequence (L=" + str(len(s)) + "):\n'" + s + "'\n\n")

    # Di-nucleotides
    di_list = make_di_kmers()
    di_results = count_kmer_stuff(s, di_list, 2)
    
    text_out.insert(tk.END, "=== Di-nucleotide (2-mer) Results ===\n")
    sorted_di = sorted(di_results.items())
    for k, p in sorted_di:
        text_out.insert(tk.END, k + ": " + "{:.2f}".format(p) + "%\n")
    text_out.insert(tk.END, "=================================\n\n")
    
    # Tri-nucleotides
    tri_list = make_tri_kmers()
    tri_results = count_kmer_stuff(s, tri_list, 3)

    text_out.insert(tk.END, "=== Tri-nucleotide (3-mer) Results ===\n")
    sorted_tri = sorted(tri_results.items())
    for k, p in sorted_tri:
        text_out.insert(tk.END, k + ": " + "{:.2f}".format(p) + "%\n")
    text_out.insert(tk.END, "==================================\n")
    
    text_out.insert(tk.END, "\n")

if __name__ == "__main__":
    root = tk.Tk()
    root.title("DNA Sequence Analyzer")
    
    main_label = tk.Label(root, text="Enter DNA Sequence:", font=("Arial", 12, "bold"))
    main_label.pack()

    seq_entry = tk.Entry(root, width=60, bd=2)
    seq_entry.insert(0, SEQUENCE)
    seq_entry.pack()

    analyze_button = tk.Button(root, text="Analyze the Sequence", command=button_click, bg="green", fg="white", font=("Arial", 10, "bold"))
    analyze_button.pack()

    results_label = tk.Label(root, text="Results:", font=("Arial", 12, "bold"))
    results_label.pack()

    text_out = scrolledtext.ScrolledText(root, width=65, height=25, font=("Courier", 10), bd=2)
    text_out.pack()

    root.mainloop()
