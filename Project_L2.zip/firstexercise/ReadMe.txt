Project Authors: Pelmus Antonio Bogdan, Buga Mihai
Involvement in the project: Code, Logic - Pelmus Antonio
Graphical User Interface, Code Debugging - Buga Mihai
Group: 1232A
Prerequisitories: tkinter library (GUI), Python 3.x
Project utility: This program uses a simple window to figure out how
often small DNA pieces (dinucleotides and trinucleotides) show up in a long DNA sequence.