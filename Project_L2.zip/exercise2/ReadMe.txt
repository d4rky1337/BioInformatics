Project Authors: Pelmus Antonio Bogdan, Buga Mihai
Involvement in the project: Code, Logic - Pelmus Antonio
Code, Code Debugging - Buga Mihai
Group: 1232A
