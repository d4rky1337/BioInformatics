from collections import OrderedDict, Counter

VALID_CHARS = set("ACGTUacgtuNn")

def clean_seq(seq):
    filtered = [c for c in seq if c in VALID_CHARS]
    return "".join(filtered).upper()

def find_kmers(seq, k):
    if k <= 0:
        raise ValueError("k must be positive")
    if len(seq) < k:
        return [], {}, {}

    order_dict = OrderedDict()
    counts = Counter()

    for i in range(len(seq) - k + 1):
        kmer = seq[i:i+k]
        if not set(kmer).issubset(VALID_CHARS | set("ACGTUN")):
            continue
        kmer = kmer.upper()
        counts[kmer] += 1
        if kmer not in order_dict:
            order_dict[kmer] = i

    order = list(order_dict.keys())
    first_pos = dict(order_dict)
    return order, dict(counts), first_pos

def report_motifs(seq):
    seq = clean_seq(seq)
    print("Sequence length:", len(seq))
    print()

    for k in (2, 3):
        order, counts, first_pos = find_kmers(seq, k)
        print("k=" + str(k), "motifs present:", len(order), "unique")
        if not order:
            print("(None)")
            print()
            continue

        print("Motif  Count  FirstPos")
        print("-----  -----  --------")
        for m in order:
            print(m.ljust(5), str(counts[m]).rjust(5), str(first_pos[m]).rjust(8))
        print()

SEQ = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        input_seq = " ".join(sys.argv[1:])
    else:
        input_seq = SEQ
    report_motifs(input_seq)