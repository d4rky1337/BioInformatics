import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np

# --- ALGORITHM LOGIC ---

def needleman_wunsch(seq1, seq2, match_score=1, mismatch_score=-1, gap_penalty=0):
    n = len(seq1)
    m = len(seq2)

    # Initialize score matrix
    score_matrix = np.zeros((n + 1, m + 1), dtype=int)
    
    # Initialize gap penalties for the first row/col
    for i in range(1, n + 1):
        score_matrix[i][0] = i * gap_penalty
    for j in range(1, m + 1):
        score_matrix[0][j] = j * gap_penalty

    # Fill matrix
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if seq1[i - 1] == seq2[j - 1]:
                diagonal_score = score_matrix[i - 1][j - 1] + match_score
            else:
                diagonal_score = score_matrix[i - 1][j - 1] + mismatch_score
            
            up_score = score_matrix[i - 1][j] + gap_penalty
            left_score = score_matrix[i][j - 1] + gap_penalty
            
            score_matrix[i][j] = max(diagonal_score, up_score, left_score)

    # Traceback
    align1 = ""
    align2 = ""
    path_points = [] # For drawing the red path on the grid
    
    i, j = n, m
    path_points.append((i, j))

    while i > 0 and j > 0:
        score_current = score_matrix[i][j]
        score_diagonal = score_matrix[i - 1][j - 1]
        score_up = score_matrix[i - 1][j]
        score_left = score_matrix[i][j - 1]
        
        is_match = seq1[i - 1] == seq2[j - 1]
        
        if is_match and score_current == score_diagonal + match_score:
            align1 += seq1[i - 1]
            align2 += seq2[j - 1]
            i -= 1
            j -= 1
        elif not is_match and score_current == score_diagonal + mismatch_score:
             align1 += seq1[i - 1]
             align2 += seq2[j - 1]
             i -= 1
             j -= 1
        elif score_current == score_left + gap_penalty:
            align1 += "-"
            align2 += seq2[j - 1]
            j -= 1
        elif score_current == score_up + gap_penalty:
            align1 += seq1[i - 1]
            align2 += "-"
            i -= 1
        
        path_points.append((i, j))

    while i > 0:
        align1 += seq1[i - 1]
        align2 += "-"
        i -= 1
        path_points.append((i, j))
    while j > 0:
        align1 += "-"
        align2 += seq2[j - 1]
        j -= 1
        path_points.append((i, j))

    return align1[::-1], align2[::-1], score_matrix, path_points

# --- GUI LOGIC ---

class AlignmentApp:
    def __init__(self, root):
        self.root = root
        self.root.title("DNA Sequence Aligner (Needleman-Wunsch)")
        self.root.geometry("1100x650")

        # --- Frames Layout ---
        # Top container
        top_frame = tk.Frame(root)
        top_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left Column (Controls)
        left_col = tk.Frame(top_frame, width=300)
        left_col.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Right Column (Graphics)
        right_col = tk.Frame(top_frame)
        right_col.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Bottom Frame (Text Output)
        bottom_frame = tk.Frame(root, height=200)
        bottom_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)

        # --- LEFT COLUMN: Inputs ---
        
        # Sequence Inputs
        seq_frame = tk.LabelFrame(left_col, text="Sequences")
        seq_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(seq_frame, text="Sq 1 =").grid(row=0, column=0, sticky="e")
        self.entry_seq1 = tk.Entry(seq_frame, width=25)
        self.entry_seq1.grid(row=0, column=1, padx=5, pady=2)
        self.entry_seq1.insert(0, "ACCGTGAAGCCAATAC") # Default

        tk.Label(seq_frame, text="Sq 2 =").grid(row=1, column=0, sticky="e")
        self.entry_seq2 = tk.Entry(seq_frame, width=25)
        self.entry_seq2.grid(row=1, column=1, padx=5, pady=2)
        self.entry_seq2.insert(0, "AGCGTGCAGCCAATAC") # Default

        # Parameters
        param_frame = tk.LabelFrame(left_col, text="Parameters")
        param_frame.pack(fill=tk.X, pady=5)

        tk.Label(param_frame, text="Gap =").grid(row=0, column=0, sticky="e")
        self.entry_gap = tk.Entry(param_frame, width=5)
        self.entry_gap.grid(row=0, column=1, pady=2)
        self.entry_gap.insert(0, "0")

        tk.Label(param_frame, text="Mach =").grid(row=1, column=0, sticky="e")
        self.entry_match = tk.Entry(param_frame, width=5)
        self.entry_match.grid(row=1, column=1, pady=2)
        self.entry_match.insert(0, "1")

        tk.Label(param_frame, text="MMach =").grid(row=2, column=0, sticky="e")
        self.entry_mismatch = tk.Entry(param_frame, width=5)
        self.entry_mismatch.grid(row=2, column=1, pady=2)
        self.entry_mismatch.insert(0, "-1")

        # Align Button
        self.btn_align = tk.Button(left_col, text="Align", command=self.run_alignment, height=2, bg="#dddddd")
        self.btn_align.pack(fill=tk.X, pady=10)
        
        # --- REMOVED PRESETS SECTION HERE ---

        # --- RIGHT COLUMN: Canvases ---

        # Heatmap
        self.heatmap_frame = tk.LabelFrame(right_col, text="Graphic representation (Heatmap)")
        self.heatmap_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        self.canvas_heatmap = tk.Canvas(self.heatmap_frame, bg="black")
        self.canvas_heatmap.pack(fill=tk.BOTH, expand=True)

        # Traceback Grid
        self.grid_frame = tk.LabelFrame(right_col, text="Traceback Path")
        self.grid_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        self.canvas_grid = tk.Canvas(self.grid_frame, bg="lightyellow")
        self.canvas_grid.pack(fill=tk.BOTH, expand=True)

        # --- BOTTOM FRAME: Output Text ---
        
        lbl_out = tk.Label(bottom_frame, text="Show Alignment:", anchor="w")
        lbl_out.pack(fill=tk.X)
        
        self.text_out = tk.Text(bottom_frame, height=8, font=("Courier New", 10))
        self.text_out.pack(fill=tk.BOTH, expand=True)
        
        # Initial Run
        self.run_alignment()

    def run_alignment(self):
        # 1. Get Inputs
        s1 = self.entry_seq1.get().upper()
        s2 = self.entry_seq2.get().upper()
        
        try:
            gap = int(self.entry_gap.get())
            match = int(self.entry_match.get())
            mismatch = int(self.entry_mismatch.get())
        except ValueError:
            messagebox.showerror("Error", "Parameters must be integers.")
            return

        # 2. Run Algorithm
        res_s1, res_s2, matrix, path = needleman_wunsch(s1, s2, match, mismatch, gap)

        # 3. Update Text Output
        self.update_text_output(res_s1, res_s2, s1, s2)
        
        # 4. Draw Graphics
        self.draw_heatmap(matrix)
        self.draw_grid(len(s1), len(s2), path)

    def update_text_output(self, a1, a2, orig_s1, orig_s2):
        self.text_out.delete("1.0", tk.END)
        
        # Match lines
        connections = ""
        matches = 0
        for k in range(len(a1)):
            if a1[k] == a2[k] and a1[k] != '-':
                connections += "|"
                matches += 1
            else:
                connections += " "
        
        output = f"{a1}\n{connections}\n{a2}\n\n"
        output += f"Matches = {matches}\n"
        output += f"Length = {len(a1)}\n"
        if len(a1) > 0:
            similarity = int((matches / len(a1)) * 100)
        else:
            similarity = 0
        output += f"Similarity = {similarity} %\n"
        output += f"Tracing back: M[{len(orig_s1)},{len(orig_s2)}]"
        
        self.text_out.insert(tk.END, output)

    def draw_heatmap(self, matrix):
        self.canvas_heatmap.delete("all")
        
        # Normalize matrix for colors
        min_val = np.min(matrix)
        max_val = np.max(matrix)
        rows, cols = matrix.shape
        
        w = self.canvas_heatmap.winfo_width()
        h = self.canvas_heatmap.winfo_height()
        
        if w < 10: w, h = 300, 300 
        
        cell_w = w / cols
        cell_h = h / rows
        
        for r in range(rows):
            for c in range(cols):
                val = matrix[r][c]
                # Map value to color intensity (Red/Purple theme like image)
                if max_val == min_val:
                    intensity = 0
                else:
                    intensity = (val - min_val) / (max_val - min_val)
                
                # Create a gradient from dark blue/purple to bright red
                red = int(255 * intensity)
                blue = int(100 * (1 - intensity))
                color = f"#{red:02x}00{blue:02x}"
                
                x1 = c * cell_w
                y1 = r * cell_h
                x2 = x1 + cell_w
                y2 = y1 + cell_h
                
                self.canvas_heatmap.create_rectangle(x1, y1, x2, y2, fill=color, outline="")

    def draw_grid(self, n, m, path):
        self.canvas_grid.delete("all")
        
        w = self.canvas_grid.winfo_width()
        h = self.canvas_grid.winfo_height()
        if w < 10: w, h = 300, 300
        
        rows = n + 1
        cols = m + 1
        cell_w = w / cols
        cell_h = h / rows

        # Draw grid lines
        for r in range(rows + 1):
            self.canvas_grid.create_line(0, r * cell_h, w, r * cell_h, fill="gray")
        for c in range(cols + 1):
            self.canvas_grid.create_line(c * cell_w, 0, c * cell_w, h, fill="gray")

        # Draw Path (Red squares)
        # Note: path contains (row, col) indices
        for (r, c) in path:
            x1 = c * cell_w
            y1 = r * cell_h
            x2 = x1 + cell_w
            y2 = y1 + cell_h
            self.canvas_grid.create_rectangle(x1, y1, x2, y2, fill="#cc3333", outline="black")

# --- MAIN LOOP ---

if __name__ == "__main__":
    root = tk.Tk()
    app = AlignmentApp(root)
    # Trigger an update so canvases get correct sizes
    root.update() 
    app.run_alignment()
    root.mainloop()