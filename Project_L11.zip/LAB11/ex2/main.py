# -*- coding: utf-8 -*-
"""
Created on Thu Dec 11 14:30:44 2025

@author: Antonio
"""

import matplotlib.pyplot as plt

# --- 1. Native Smith-Waterman Implementation ---
def smith_waterman_pure_python(seq1, seq2, match=3, mismatch=-3, gap=-2):
    """
    Implements the Smith-Waterman Local Alignment algorithm from scratch.
    
    Optimized for Memory: 
    Instead of storing the full M x N matrix (which crashes memory),
    we only store 2 rows (current and previous) to calculate scores.
    We track the 'max_score' found anywhere in the matrix.
    """
    m, n = len(seq1), len(seq2)
    
    # Initialize the "previous" row with zeros
    # This represents the row i-1 in the matrix
    prev_row = [0] * (n + 1)
    
    max_score = 0
    
    # Loop through sequence 1 (Query)
    for i in range(1, m + 1):
        # Create the "current" row
        curr_row = [0] * (n + 1)
        
        # Loop through sequence 2 (Target Window)
        for j in range(1, n + 1):
            # Calculate substitution score
            if seq1[i - 1] == seq2[j - 1]:
                score_diag = prev_row[j - 1] + match
            else:
                score_diag = prev_row[j - 1] + mismatch
            
            # Calculate gap scores (deletion/insertion)
            score_up = prev_row[j] + gap
            score_left = curr_row[j - 1] + gap
            
            # Local alignment rule: Scores cannot be negative (reset to 0)
            cell_value = max(0, score_diag, score_up, score_left)
            
            curr_row[j] = cell_value
            
            # Update global maximum found so far
            if cell_value > max_score:
                max_score = cell_value
        
        # Move current row to previous for the next iteration
        prev_row = curr_row

    return max_score

# --- 2. The "In-Between" Layer (Window Manager) ---
def windowed_alignment_native(file1_path, file2_path, window_size=300, step_size=150):
    """
    Manages the data loading and window sliding manually.
    """
    # Helper to load file manually without Biopython
    def read_fasta_native(path):
        with open(path, 'r') as f:
            lines = f.readlines()
        # Skip the header (>Line) and join the sequence lines
        seq = ''.join([line.strip() for line in lines if not line.startswith('>')])
        return seq

    seq_flu = read_fasta_native(file1_path)
    seq_covid = read_fasta_native(file2_path)
    
    # Limit Seq1 length for demonstration speed (Pure python is slow!)
    # We will use the first 500bp of Flu to scan against Covid
    # Remove this slice if you want to wait for the full run
    seq_flu_subset = seq_flu[:500] 

    print(f"Aligning Flu segment ({len(seq_flu_subset)}bp) against Covid ({len(seq_covid)}bp)")
    print("Running Native Sequence Alignment (This may take time)...")

    scores = []
    positions = []
    
    # Sliding Window Loop
    total_len = len(seq_covid)
    for start_pos in range(0, total_len - window_size + 1, step_size):
        end_pos = start_pos + window_size
        
        # The Chunking/Windowing logic
        covid_window = seq_covid[start_pos:end_pos]
        
        # Call our native algorithm
        score = smith_waterman_pure_python(seq_flu_subset, covid_window)
        
        scores.append(score)
        positions.append(start_pos)
        
        # Simple progress bar
        if len(positions) % 10 == 0:
            print(f"Scanned {start_pos}/{total_len} bp...")

    return positions, scores

# --- 3. Visualization ---
def plot_results(positions, scores):
    plt.figure(figsize=(12, 6))
    plt.plot(positions, scores, color='darkblue', label='Similarity Score')
    plt.fill_between(positions, scores, color='lightblue', alpha=0.5)
    plt.xlabel('Position in Covid-19 Genome')
    plt.ylabel('Smith-Waterman Alignment Score')
    plt.title('Native Alignment: Influenza vs Covid-19')
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.show()

# --- Execution ---
# Make sure your files are named correctly in the same folder
flu_file = "influenza.fasta"
covid_file = "covid19.fasta"

try:
    # Run the native pipeline
    pos, val = windowed_alignment_native(flu_file, covid_file)
    plot_results(pos, val)
except FileNotFoundError:
    print("Please ensure 'influenza.fasta' and 'covid19.fasta' are in the folder.")