from Bio import Entrez, SeqIO
import random
import time
import matplotlib.pyplot as plt


Entrez.email = "antpbb@gmail.com"
VIRUS_IDS = [
    "NC_001802.1",
    "NC_045512.2",
    "NC_001434.1",
    "NC_002528.1",
    "NC_003899.1",
    "NC_002645.1",
    "NC_002058.1",
    "NC_001710.1",
    "NC_001781.1",
    "NC_006213.1",
]

def fetch_sequence(accession_id):
    handle = Entrez.efetch(db="nucleotide", id=accession_id, rettype="fasta", retmode="text")
    record = SeqIO.read(handle, "fasta")
    handle.close()
    return str(record.seq)

def create_fragments(sequence, num_fragments=1200, min_frag=90, max_frag=140):
    fragments = []
    seq_len = len(sequence)
    for _ in range(num_fragments):
        fragment_len = random.randint(min_frag, max_frag)
        start_index = random.randint(0, seq_len - fragment_len)
        fragments.append(sequence[start_index:start_index + fragment_len])
    return fragments

def find_overlap(s1, s2, min_overlap=10):
    max_possible = min(len(s1), len(s2))
    for k in range(max_possible, min_overlap - 1, -1):
        if s1.endswith(s2[:k]):
            return k
    return 0

def assemble_fragments(fragments):
    graph = {i: [] for i in range(len(fragments))}
    for i, frag1 in enumerate(fragments):
        for j, frag2 in enumerate(fragments):
            if i != j:
                overlap_len = find_overlap(frag1, frag2)
                if overlap_len >= 10:
                    graph[i].append((j, overlap_len))

    visited_nodes = set()
    path = []
    
    current_node = 0
    visited_nodes.add(current_node)
    path.append(current_node)

    while True:
        neighbors = graph.get(current_node, [])
        unvisited = [(idx, o_len) for idx, o_len in neighbors if idx not in visited_nodes]
        
        if not unvisited:
            break
            
        next_node = max(unvisited, key=lambda item: item[1])[0]
        visited_nodes.add(next_node)
        path.append(next_node)
        current_node = next_node

    assembled_genome = fragments[path[0]]
    for k in range(1, len(path)):
        prev_node = path[k - 1]
        curr_node = path[k]
        
        overlap_len = find_overlap(fragments[prev_node], fragments[curr_node])
        assembled_genome += fragments[curr_node][overlap_len:]
        
    return assembled_genome

def compute_gc_percent(sequence):
    g_count = sequence.count('G')
    c_count = sequence.count('C')
    return (g_count + c_count) / len(sequence) * 100

timing_data = []
gc_data = []

print("Starting genome assembly simulation...")

for virus_id in VIRUS_IDS:
    full_sequence = fetch_sequence(virus_id)
    
    fragments = create_fragments(full_sequence)
    
    t_start = time.time()
    assembled_genome = assemble_fragments(fragments)
    t_end = time.time()
    
    duration_ms = (t_end - t_start) * 1000
    gc_percent = compute_gc_percent(full_sequence)
    
    timing_data.append(duration_ms)
    gc_data.append(gc_percent)
    
    print(f"Processed {virus_id}: Time={duration_ms:.1f} ms, GC={gc_percent:.2f}%")

print("Generating plot...")

plt.scatter(gc_data, timing_data)
plt.xlabel('G+C Content (%)')
plt.ylabel('Assembly Duration (ms)')
plt.title('Genome Assembly Time vs. G+C Content')
plt.grid(True)
plt.show()
