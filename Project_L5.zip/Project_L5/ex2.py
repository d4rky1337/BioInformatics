from Bio import SeqIO
import random
from difflib import SequenceMatcher



try:
    fasta_record = SeqIO.read("arbitrary_dna.fasta", "fasta")
    source_sequence = str(fasta_record.seq)
except FileNotFoundError:
    print("Error: 'arbitrary_dna.fasta' not found.")
    print("Please create this file with a DNA sequence in FASTA format.")
    source_sequence = ""
except Exception as e:
    print(f"An error occurred reading the FASTA file: {e}")
    source_sequence = ""

if source_sequence:
    num_fragments = 1800
    dna_fragments = []
    source_len = len(source_sequence)

    for _ in range(num_fragments):
        frag_len = random.randint(90, 160)
        start_idx = random.randint(0, source_len - frag_len)
        dna_fragments.append(source_sequence[start_idx:start_idx + frag_len])

    def find_suffix_prefix_match(seq1, seq2, min_match=10):
        max_possible = min(len(seq1), len(seq2))
        for k in range(max_possible, min_match - 1, -1):
            if seq1.endswith(seq2[:k]):
                return k
        return 0

    overlap_adj_list = {i: [] for i in range(num_fragments)}

    for i, frag1 in enumerate(dna_fragments):
        for j, frag2 in enumerate(dna_fragments):
            if i == j:
                continue
            
            match_len = find_suffix_prefix_match(frag1, frag2)
            
            if match_len >= 10:
                overlap_adj_list[i].append((j, match_len))

    visited_nodes = set()
    rebuild_path = []
    
    current_node = 0
    visited_nodes.add(current_node)
    rebuild_path.append(current_node)

    while True:
        potential_neighbors = overlap_adj_list.get(current_node, [])
        unvisited = [(idx, o_len) for idx, o_len in potential_neighbors if idx not in visited_nodes]
        
        if not unvisited:
            break
            
        next_node = max(unvisited, key=lambda item: item[1])[0]
        visited_nodes.add(next_node)
        rebuild_path.append(next_node)
        current_node = next_node

    reconstructed_dna = dna_fragments[rebuild_path[0]]
    
    for k in range(1, len(rebuild_path)):
        prev_idx = rebuild_path[k - 1]
        curr_idx = rebuild_path[k]
        
        match_len = find_suffix_prefix_match(dna_fragments[prev_idx], dna_fragments[curr_idx])
        reconstructed_dna += dna_fragments[curr_idx][match_len:]

    print(f"Original sequence length: {len(source_sequence)}")
    print(f"Reconstructed sequence length: {len(reconstructed_dna)}")
    
    similarity_score = SequenceMatcher(None, source_sequence, reconstructed_dna).ratio()
    print(f"Reconstruction similarity: {similarity_score:.4f}")
    
    print("\nFirst 500 bases of reconstructed DNA:")
    print(reconstructed_dna[:500])
